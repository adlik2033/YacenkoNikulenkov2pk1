package com.simpleRestApi.demo.controllers;
package com.simpleRestApi.demo.Model;
import com.simpleRestApi.demo.Model.TemplateModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.sql.Timestamp;
import java.util.Date;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
@Controller
@RequestMapping("/rest/home")
class HomeController {
    @ResponseBody
    @RequestMapping(value = "", method=RequestMethod.GET)
    public ResponseEntity<TemplateModel> response(){
        Date date = new Date();
        Timestamp timestamp = new Timestamp(date.getTime());

        TemplateModel model = new TemplateModel();
        model.setMassage("json-ответ");
        model.setTime((timestamp.toString()));

        return ResponseEntity.ok(model);
    }
}



